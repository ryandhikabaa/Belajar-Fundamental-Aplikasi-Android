package com.ryandhikaba.githubuserbyryandhikabaa.utils

class Config {
    object Constants {
        const val EROR_JARINGAN_ON_ERROR = "Opps! Mohon maaf terjadi kesalahan sistem, silahkan ulangi beberapa saat kembali "
        const val OPPS = "Opps!, Respon Server Gagal, silahkan ulangi beberapa saat kembali"
    }
}